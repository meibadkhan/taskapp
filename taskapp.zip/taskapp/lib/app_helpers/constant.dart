import 'package:flutter/cupertino.dart';

SizedBox kheightBoxed ( ){
  return SizedBox(height: 10,);
}
SizedBox kwidthBoxed ( ){
  return SizedBox(width: 10,);
}

