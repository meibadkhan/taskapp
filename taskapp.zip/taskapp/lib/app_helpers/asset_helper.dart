class AssetHelper {
  static const String bg = "assets/bg.png";
}