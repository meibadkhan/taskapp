
const String baseUrl = "https://tasks.coderzsolution.com/api";

class ApiEndPoint{

}
