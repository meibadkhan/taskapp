package com.itcoderz.taskapp.taskapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
